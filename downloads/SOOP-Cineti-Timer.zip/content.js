(() => {
  if (window.__SOOP_VOD_OVERLAY_ACTIVE__) return;
  window.__SOOP_VOD_OVERLAY_ACTIVE__ = true;
  let last = '';
  let lastSuccessfulSend = 0;
  function send() {
    const video = document.querySelector('video#video') || document.querySelector('video:not(#adVideo)');
    const title = document.querySelector('.broadcast_title')?.textContent?.trim()
      || document.title.replace(/\s*\|\s*SOOP VOD\s*$/, '').trim();
    if (!video || !title) return;
    const payload = {
      title,
      currentTime: Number(video.currentTime) || 0,
      duration: Number.isFinite(video.duration) ? video.duration : 0,
      paused: video.paused,
    };
    const fingerprint = JSON.stringify([payload.title, Math.floor(payload.currentTime * 2), payload.duration, payload.paused]);
    if (fingerprint === last && Date.now() - lastSuccessfulSend < 1500) return;
    last = fingerprint;
    chrome.runtime.sendMessage({ type: 'SOOP_VOD_STATE', payload }, response => {
      if (chrome.runtime.lastError) {
        console.warn('[SOOP Overlay] 확장 프로그램 연결 실패:', chrome.runtime.lastError.message);
        return;
      }
      if (response?.ok) lastSuccessfulSend = Date.now();
      else console.warn('[SOOP Overlay] 로컬 서버 연결 실패:', response?.error || 'unknown error');
    });
  }
  setInterval(send, 1000);
  document.addEventListener('play', send, true);
  document.addEventListener('pause', send, true);
  window.addEventListener('popstate', () => setTimeout(send, 500));
  send();
})();
