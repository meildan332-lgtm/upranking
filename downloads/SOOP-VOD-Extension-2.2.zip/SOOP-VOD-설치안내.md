# SOOP VOD 오버레이 2.2

1. SOOP-VOD-Extension-2.2.zip의 압축을 해제합니다.
2. Chrome에서 chrome://extensions 또는 Edge에서 edge://extensions를 엽니다.
3. 개발자 모드를 켜고 압축해제된 확장 프로그램을 로드하여 extension 폴더를 선택합니다.
4. 기존 확장 프로그램을 사용하고 있다면 새 폴더로 다시 등록하거나 기존 폴더를 교체하고 새로고침합니다.
5. SOOP VOD 탭을 새로고침한 다음 영상을 재생합니다.
6. 확장 프로그램 팝업의 현재 VOD 다시 연결을 누르고 주소 복사를 누릅니다.
7. OBS 브라우저 소스에 복사한 개인 URL을 붙여넣습니다. 크기는 1200 × 220입니다.

로컬 서버나 Node.js는 필요하지 않습니다. 예전 localhost 또는 chatgpt.site 주소는 사용할 수 없습니다.

## 운영자 최초 설정

Vercel upranking 프로젝트에서 Upstash Redis를 연결하고 Production 환경에 아래 환경변수가 있는지 확인한 뒤 재배포해야 합니다.

- UPSTASH_REDIS_REST_URL
- UPSTASH_REDIS_REST_TOKEN

Vercel Marketplace가 KV_REST_API_URL / KV_REST_API_TOKEN 이름을 생성하는 경우도 지원합니다.

Supabase는 필요하지 않습니다. Redis 자격증명은 Vercel 환경변수에만 저장하며 확장 프로그램에 넣지 않습니다.

OBS 주소를 아는 사람은 해당 VOD 제목과 재생 시간을 볼 수 있습니다. 개인 주소는 필요한 곳에만 공유하세요.
